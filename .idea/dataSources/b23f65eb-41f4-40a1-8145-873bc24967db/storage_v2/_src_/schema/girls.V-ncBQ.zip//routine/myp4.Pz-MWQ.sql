create
    definer = root@localhost procedure myp4(IN beautyName varchar(20), OUT boyName varchar(20))
BEGIN
SELECT bo.boyName INTO boyName
FROM boys bo
INNER JOIN beauty b ON bo.id=b.boyfriend_id
WHERE b.name=beautyName;
END;

