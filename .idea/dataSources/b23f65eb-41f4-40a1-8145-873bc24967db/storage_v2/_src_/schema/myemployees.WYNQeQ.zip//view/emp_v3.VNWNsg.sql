create view emp_v3 as
select `myemployees`.`employees`.`department_id` AS `department_id`,
       max(`myemployees`.`employees`.`salary`)   AS `max(salary)`
from `myemployees`.`employees`
group by `myemployees`.`employees`.`department_id`
having (max(`myemployees`.`employees`.`salary`) > 12000);

