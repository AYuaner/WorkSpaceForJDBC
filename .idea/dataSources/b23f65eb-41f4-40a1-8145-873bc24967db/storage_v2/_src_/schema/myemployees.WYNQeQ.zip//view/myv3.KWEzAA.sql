create view myv3 as
select `myemployees`.`myv2`.`ag` AS `ag`, `myemployees`.`myv2`.`department_id` AS `department_id`
from `myemployees`.`myv2`
order by `myemployees`.`myv2`.`ag`
limit 1;

