create
    definer = root@localhost procedure myp5(IN beautyName varchar(20), OUT boyName varchar(20), OUT CP int)
BEGIN
SELECT bo.boyName,userCP INTO boyName,CP
FROM boys bo
INNER JOIN beauty b ON bo.id=b.boyfriend_id
WHERE b.name=beautyName;
END;

