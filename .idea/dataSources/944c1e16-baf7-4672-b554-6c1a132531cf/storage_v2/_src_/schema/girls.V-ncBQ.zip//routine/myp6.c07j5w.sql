create
    definer = root@localhost procedure myp6(INOUT a int, INOUT b int)
BEGIN
SET a=a*2;
SET b=b*2;
END;

