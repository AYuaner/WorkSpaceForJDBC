create
    definer = root@localhost procedure myp1()
begin
	insert into admin(username,password)
	values('john1','0000'),('lily','0000'),('rose','0000'),('jack','0000'),('tom','0000');
end;

