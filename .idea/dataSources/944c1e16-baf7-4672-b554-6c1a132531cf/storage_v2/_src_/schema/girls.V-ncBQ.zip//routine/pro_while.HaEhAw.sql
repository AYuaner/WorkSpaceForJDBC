create
    definer = root@localhost procedure pro_while(IN insertCount int)
BEGIN
DECLARE i INT DEFAULT 1;
WHILE i<= insertCount DO
INSERT INTO ADMIN(username,PASSWORD) VALUES(CONCAT('Rose',i),'666');
SET i=i+1;
END WHILE;
END;

