create
    definer = root@localhost procedure pro_while2(IN insertCount int)
BEGIN
DECLARE i INT DEFAULT 1;
a:WHILE i<insertCount DO
INSERT INTO ADMIN(username,PASSWORD) VALUES(CONCAT('xiaohua',i),'0000');
IF i>=20 THEN LEAVE a;
END IF;
SET i=i+1;
END WHILE a;
END;

