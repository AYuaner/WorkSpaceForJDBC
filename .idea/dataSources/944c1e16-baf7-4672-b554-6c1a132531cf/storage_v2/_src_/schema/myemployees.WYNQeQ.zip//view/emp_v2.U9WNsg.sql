create definer = root@localhost view emp_v2 as
select `d`.`department_id`   AS `department_id`,
       `d`.`department_name` AS `department_name`,
       `d`.`manager_id`      AS `manager_id`,
       `d`.`location_id`     AS `location_id`
from (`myemployees`.`departments` `d`
         join `myemployees`.`emp_v3` `e` on ((`myemployees`.`e`.`department_id` = `d`.`department_id`)));

