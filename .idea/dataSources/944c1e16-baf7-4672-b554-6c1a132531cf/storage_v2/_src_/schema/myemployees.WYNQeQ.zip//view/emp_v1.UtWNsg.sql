create definer = root@localhost view emp_v1 as
select `myemployees`.`employees`.`last_name` AS `last_name`,
       `myemployees`.`employees`.`salary`    AS `salary`,
       `myemployees`.`employees`.`email`     AS `email`
from `myemployees`.`employees`
where (`myemployees`.`employees`.`phone_number` like '011%');

